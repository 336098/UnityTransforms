﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Transforms : MonoBehaviour
{
    public GameObject transformer;
    public GameObject scaler;
    public GameObject rotater;

    private Vector3 translateDir;
    private Vector3 scalerDir;

    // Start is called before the first frame update
    void Start()
    {
        transformer = GameObject.CreatePrimitive(PrimitiveType.Cube);
        transformer.transform.position = new Vector3(0, 0, 0);
        transformer.GetComponent<Renderer>().material.color = Color.blue;

        scaler = GameObject.CreatePrimitive(PrimitiveType.Cube);
        scaler.transform.position = new Vector3(5, 0, 0);
        scaler.GetComponent<Renderer>().material.color = Color.green;

        rotater = GameObject.CreatePrimitive(PrimitiveType.Cube);
        rotater.transform.position = new Vector3(-5, 0, 0);
        rotater.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);
        rotater.GetComponent<Renderer>().material.color = Color.red;

        translateDir = new Vector3(0, 0, 1);
        scalerDir = new Vector3(0.5f, 0.5f, 0.5f);
    }

    // Update is called once per frame
    void Update()
    {
        //Translates the middle shape and reverses direction when far away
        transformer.transform.Translate(translateDir * Time.deltaTime);
        if (transformer.transform.position.z <= 0)
            translateDir.z = 1;
        else if (transformer.transform.position.z >= 10)
            translateDir.z = -1;

        //Manipulate the scale to appear as if it's pulsing
        scaler.transform.localScale += scalerDir * Time.deltaTime;
        if (scaler.transform.localScale.x <= 1)
        {
            scalerDir.x = 0.5f;
            scalerDir.y = 0.5f;
            scalerDir.z = 0.5f;
        }
        else if (scaler.transform.localScale.x >= 7)
        {
            scalerDir.x = -0.5f;
            scalerDir.y = -0.5f;
            scalerDir.z = -0.5f;
        }

        //Rotate the left object every frame
        rotater.transform.Rotate(new Vector3(0, 30, 0) * Time.deltaTime);
    }
}
